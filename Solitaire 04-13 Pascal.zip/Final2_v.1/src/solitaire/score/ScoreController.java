package solitaire.score;

public class ScoreController {

}
 