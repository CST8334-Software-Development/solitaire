package solitaire.solitaire;

import javax.swing.*;

public class CustomMenuBar extends JMenuBar {
    private final Solitaire game;

    public CustomMenuBar(Solitaire game) {
        this.game = game;  
        createGameMenu();
        createOptionsMenu();
    }

    private void createGameMenu() {
        JMenu gameMenu = new JMenu("Game");
        
        JMenuItem newGameItem = new JMenuItem("New Game");
        newGameItem.addActionListener(e -> game.newGameItem(newGameItem));
        
        JMenuItem showScoreBoardItem = new JMenuItem("Show ScoreBoard");
        showScoreBoardItem.addActionListener(e -> game.scoreBoardItem(showScoreBoardItem));
        
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> game.exitItem(exitItem));
        
        JMenuItem wastePileItem = new JMenuItem("Draw 1 or 3 cards");
        wastePileItem.addActionListener(e -> game.wastePileItem(wastePileItem));
        
        gameMenu.add(newGameItem);
        gameMenu.add(showScoreBoardItem);
        gameMenu.add(wastePileItem);
        gameMenu.add(exitItem);
        super.add(gameMenu);
    }

    private void createOptionsMenu() {
        JMenu optionsMenu = new JMenu("Options");
        JMenuItem changeBackgroundItem = new JMenuItem("Change Background");
        changeBackgroundItem.addActionListener(e -> game.backgroundItem(changeBackgroundItem));
        optionsMenu.add(changeBackgroundItem);
        super.add(optionsMenu);
    }
}
