package score;

public class ScoreController {

}
