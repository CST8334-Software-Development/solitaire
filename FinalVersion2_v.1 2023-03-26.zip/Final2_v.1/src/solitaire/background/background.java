package solitaire.background;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import com.jgoodies.forms.layout.*;
import solitaire.solitaire.*;


public class background {

	private JFrame frame;
	private Solitaire Solitaire;
	public static String BACKGROUND_FILE_PATH = "./config/background.txt";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					background window = new background();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public background() {
		
	}

	/**
	 * Initialize the contents of the frame.
	 * @wbp.parser.entryPoint
	 */
	public void initialize(Solitaire mainframe) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new FormLayout(new ColumnSpec[] {
				ColumnSpec.decode("58px"),
				ColumnSpec.decode("293px"),
				FormSpecs.LABEL_COMPONENT_GAP_COLSPEC,
				ColumnSpec.decode("20px"),},
			new RowSpec[] {
				FormSpecs.LINE_GAP_ROWSPEC,
				RowSpec.decode("17px"),
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,
				FormSpecs.RELATED_GAP_ROWSPEC,
				FormSpecs.DEFAULT_ROWSPEC,}));
		
		JLabel lblQuestion = new JLabel("Please choose a color for your background");
		lblQuestion.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuestion.setFont(new Font("Tahoma", Font.BOLD, 14));
		frame.getContentPane().add(lblQuestion, "2, 2, left, top");
		
		JButton btnREd = new JButton("Red");
		btnREd.setMaximumSize(new Dimension(10, 10));
		btnREd.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnREd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("red");
				writeBackgroundColorFile("red");
				frame.dispose();
			}
		});
		btnREd.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnREd.setAlignmentX(Component.CENTER_ALIGNMENT);
		btnREd.setMinimumSize(new Dimension(10, 10));
		btnREd.setForeground(new Color(0, 0, 0));
		btnREd.setBackground(new Color(255, 0, 0));
		frame.getContentPane().add(btnREd, "2, 6");
		
		JButton btnBlue = new JButton("Blue");
		btnBlue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("blue");
				writeBackgroundColorFile("blue");
				frame.dispose();
			}
		});
		btnBlue.setMinimumSize(new Dimension(10, 10));
		btnBlue.setMaximumSize(new Dimension(10, 10));
		btnBlue.setForeground(new Color(0, 0, 0));
		btnBlue.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnBlue.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnBlue.setBackground(new Color(0, 0, 255));
		btnBlue.setAlignmentX(0.5f);
		frame.getContentPane().add(btnBlue, "2, 8");
		
		JButton btnGreen = new JButton("Green");
		btnGreen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("green");
				writeBackgroundColorFile("green");
				frame.dispose();
			}
		});
		btnGreen.setMinimumSize(new Dimension(10, 10));
		btnGreen.setMaximumSize(new Dimension(10, 10));
		btnGreen.setForeground(new Color(0, 0, 0));
		btnGreen.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnGreen.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnGreen.setBackground(new Color(0, 128, 0));
		btnGreen.setAlignmentX(0.5f);
		frame.getContentPane().add(btnGreen, "2, 10");
		
		JButton btnLightBlue = new JButton("Light Blue");
		btnLightBlue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("light blue");
				writeBackgroundColorFile("light blue");
				frame.dispose();
			}
		});
		btnLightBlue.setMinimumSize(new Dimension(10, 10));
		btnLightBlue.setMaximumSize(new Dimension(10, 10));
		btnLightBlue.setForeground(new Color(0, 0, 0));
		btnLightBlue.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnLightBlue.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnLightBlue.setBackground(new Color(135, 206, 250));
		btnLightBlue.setAlignmentX(0.5f);
		frame.getContentPane().add(btnLightBlue, "2, 12");
		
		JButton btnLightGreen = new JButton("Light Green");
		btnLightGreen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("light green");
				writeBackgroundColorFile("light green");
				frame.dispose();
			}
		});
		btnLightGreen.setMinimumSize(new Dimension(10, 10));
		btnLightGreen.setMaximumSize(new Dimension(10, 10));
		btnLightGreen.setForeground(new Color(0, 0, 0));
		btnLightGreen.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnLightGreen.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnLightGreen.setBackground(new Color(152, 251, 152));
		btnLightGreen.setAlignmentX(0.5f);
		frame.getContentPane().add(btnLightGreen, "2, 14");
		
		JButton btnOriginal = new JButton("Original");
		btnOriginal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.changeBackgroundColor("original");
				writeBackgroundColorFile("original");
				frame.dispose();
			}
		});
		btnOriginal.setMinimumSize(new Dimension(10, 10));
		btnOriginal.setMaximumSize(new Dimension(10, 10));
		btnOriginal.setForeground(new Color(0, 0, 0));
		btnOriginal.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnOriginal.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnOriginal.setBackground(new Color(255, 165, 0));
		btnOriginal.setAlignmentX(0.5f);
		frame.getContentPane().add(btnOriginal, "2, 16");
		frame.setVisible(true);
	}
	
	public void writeBackgroundColorFile(String contents) {
		try {
	        File file = new File(BACKGROUND_FILE_PATH);
	        FileWriter writer = new FileWriter(file, false);
	        writer.write(contents);
	        writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String readBackgroundFile() {
		String line="";
		
		try {
			File file = new File(BACKGROUND_FILE_PATH);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			line = reader.readLine();
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return line;
	}
	

}
